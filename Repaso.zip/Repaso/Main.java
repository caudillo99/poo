public class Main
{
    public static void main(String[] args) {
        Persona p1 = new Persona();
        Persona p2 = new Persona("Alex");
        Persona p3 = new Persona(20);
        Persona p4 = new Persona("Alex", 20);

        System.out.println("Nombre: " + p1.nombre + "   Edad: " + p1.edad);
        System.out.println("Nombre: " + p2.nombre + "   Edad: " + p2.edad);
        System.out.println("Nombre: " + p3.nombre + "   Edad: " + p3.edad);
        System.out.println("Nombre: " + p4.nombre + "   Edad: " + p4.edad);
        System.out.println("");
        p1.unMetodo(15);
        p1.unMetodo(15.5f);
    }
}