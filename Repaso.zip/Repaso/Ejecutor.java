public class Ejecutor
{
    public static void main(String[] args) 
    {
        Estudiante e1 = new Estudiante();
        e1.mostrarInfo();
        Estudiante e2 = new Estudiante();
        e2.mostrarInfo();
        //Accediendo a la variable b static de la clase creada 
        e1.b++; //Incrementa en 1
        //Accediendo directamente desde la clase, sin instanciar un objeto     
        Estudiante.b++;
        //Como se puede ver la variable  b static es compartida por todas las
        //instacias de la clase
        e2.mostrarInfo();
    }
}