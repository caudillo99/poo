class Estudiante
{
    int a;
    static int b;

    Estudiante() {b++;} //Constructor que incerementa en 1 la variable b

    public void mostrarInfo()
    {
        System.out.println("Valor de a = " + a);
        System.out.println("Valor de a = " + b);
    }
    //en un metodo static solo pude declarar o llamar variables static 
    //se puede descomentar para ver el error
    //public static void incrementar(){a++;}

    

}